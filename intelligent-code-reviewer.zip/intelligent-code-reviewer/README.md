# 🧠 Intelligent Code Reviewer & Explainer

A Streamlit-based Generative AI application that uses **Google Gemini** to
review, explain, and improve source code. Upload a `.py`, `.js`, or `.java`
file and receive a structured report with a bug analysis, plain-language
explanation, improvement suggestions, and a fully optimized/refactored
version of the code.

---

## ✨ Features

- **Multi-language support**: Accepts Python (`.py`), JavaScript (`.js`),
  and Java (`.java`) source files.
- **File validation**: Rejects unsupported file types, empty files, and
  files that exceed a safe size limit before calling the API.
- **AI-powered analysis** via Google Gemini, returning:
  - 🐛 **Bug Report** — identified bugs, logical errors, and edge cases.
  - 📖 **Explanation** — a plain-language walkthrough of what the code does.
  - 💡 **Improvements** — concrete, actionable suggestions.
  - ✨ **Optimized Code** — a complete, refactored rewrite.
- **Structured, parsed output**: Responses are parsed into distinct
  Markdown sections and rendered with proper syntax-highlighted code
  blocks — not just a wall of raw text.
- **Robust error handling** for:
  - Missing/invalid Gemini API key
  - Empty or unreadable files
  - Invalid/unsupported file types
  - Gemini API failures or empty responses
- **Loading indicators** while the model is generating a response.
- **Clean, modular architecture** separating UI logic, prompt engineering,
  file handling, and AI logic into distinct modules.

---

## 🛠 Tech Stack

- Python 3.12+
- [Streamlit](https://streamlit.io/) — web UI
- [Google Gemini API](https://ai.google.dev/) (`google-genai` SDK)
- [python-dotenv](https://pypi.org/project/python-dotenv/) — environment
  variable management

---

## 📦 Installation

1. **Clone or download this project**, then navigate into the project
   directory:

   ```bash
   cd intelligent-code-reviewer
   ```

2. **Create and activate a virtual environment** (recommended):

   ```bash
   python3 -m venv .venv
   source .venv/bin/activate      # macOS/Linux
   .venv\Scripts\activate         # Windows
   ```

3. **Install dependencies**:

   ```bash
   pip install -r requirements.txt
   ```

---

## 🔑 Environment Setup

1. **Get a Gemini API key** from
   [Google AI Studio](https://aistudio.google.com/app/apikey).

2. **Copy the example environment file**:

   ```bash
   cp .env.example .env
   ```

3. **Edit `.env`** and paste in your actual API key:

   ```env
   GEMINI_API_KEY=your_actual_api_key_here
   ```

   The `.env` file is already excluded from version control via
   `.gitignore` — never commit real API keys.

---

## ▶️ Running Locally

Once dependencies are installed and `.env` is configured, start the app
with:

```bash
streamlit run app.py
```

Streamlit will print a local URL (typically `http://localhost:8501`) —
open it in your browser, upload a source file, and click **"Analyze
Code"**.

---

## 📁 Project Structure

```
intelligent-code-reviewer/
├── app.py                   # Streamlit UI entry point (presentation logic only)
├── requirements.txt         # Python dependencies
├── README.md                 # Project documentation (this file)
├── .gitignore                # Files/directories excluded from version control
├── .env.example               # Template for required environment variables
└── utils/
    ├── __init__.py            # Marks `utils` as a Python package
    ├── prompts.py              # All Gemini prompt templates & system instructions
    ├── file_handler.py         # File upload validation and reading
    └── analyzer.py              # Gemini API client wrapper and analysis logic
```

### Module responsibilities

| Module | Responsibility |
|---|---|
| `app.py` | Streamlit UI: file upload widget, buttons, spinners, rendering results. Contains no direct Gemini API calls. |
| `utils/prompts.py` | Defines the system instruction and prompt templates that force Gemini into a structured Markdown output. |
| `utils/file_handler.py` | Validates uploaded file extension, size, and encoding; decodes file content into text. |
| `utils/analyzer.py` | Configures the Gemini client, sends the analysis request, and handles/normalizes API errors. |

---

## 🚧 Future Improvements

- Support additional languages (C++, C#, Go, TypeScript, Rust).
- Allow pasting code directly instead of only file upload.
- Add a "diff view" comparing original vs. optimized code side-by-side.
- Persist analysis history per session (or per user, with auth).
- Add unit tests for `utils/file_handler.py` and response parsing logic.
- Support multi-file / whole-repository analysis.
- Add configurable model selection (e.g. Gemini Flash vs. Pro) in the UI.
- Export analysis results as a downloadable PDF or Markdown report.
- Add CI (lint + test) via GitHub Actions.

---

## ⚠️ Notes

- This tool is intended to **assist** code review, not replace human
  judgment — always verify AI-suggested changes before merging them.
- Large files (over ~2 MB) are rejected by default to keep the app
  responsive; this limit can be adjusted in `utils/file_handler.py`.
