"""
analyzer.py
===========

Wraps all interaction with the Google Gemini API.

This module is the only place in the codebase that talks directly to the
`google-genai` SDK. Isolating it here means:

- `app.py` never needs to know how the Gemini client is configured.
- Swapping models, providers, or SDK versions only requires changes in one
  file.
- Error handling for API failures is centralized and consistent.
"""

import os
from dataclasses import dataclass
from typing import Optional

from google import genai
from google.genai import types as genai_types

from utils.prompts import build_analysis_prompt, get_system_instruction

# Default Gemini model used for code analysis. Chosen for its strong
# reasoning ability and large context window, which suits multi-file /
# multi-hundred-line source code inputs.
DEFAULT_MODEL_NAME: str = "gemini-2.5-pro"

# Generation parameters tuned for deterministic, structured technical output.
GENERATION_CONFIG_KWARGS: dict = {
    "temperature": 0.2,
    "top_p": 0.95,
    "top_k": 40,
    "max_output_tokens": 8192,
}


@dataclass
class AnalysisResult:
    """
    Represents the outcome of a Gemini code analysis request.

    Attributes:
        success: Whether the analysis completed successfully.
        content: The raw Markdown response text from Gemini, if successful.
        error_message: Human-readable error description, if unsuccessful.
    """

    success: bool
    content: Optional[str] = None
    error_message: Optional[str] = None


class GeminiNotConfiguredError(Exception):
    """Raised when the Gemini API key is missing or invalid at configuration time."""


def is_api_key_configured() -> bool:
    """
    Check whether a Gemini API key is present in the environment.

    Returns:
        bool: True if `GEMINI_API_KEY` is set and non-empty.
    """
    api_key = os.getenv("GEMINI_API_KEY")
    return bool(api_key and api_key.strip())


def get_gemini_client() -> genai.Client:
    """
    Build a configured `google-genai` Client using the API key from the
    environment.

    Returns:
        genai.Client: A ready-to-use Gemini client.

    Raises:
        GeminiNotConfiguredError: If the `GEMINI_API_KEY` environment
            variable is missing or empty.
    """
    api_key = os.getenv("GEMINI_API_KEY")
    if not api_key or not api_key.strip():
        raise GeminiNotConfiguredError(
            "GEMINI_API_KEY is not set. Please add it to your .env file "
            "or environment variables."
        )
    return genai.Client(api_key=api_key)


def analyze_code(
    code: str,
    language: str,
    filename: str,
    model_name: str = DEFAULT_MODEL_NAME,
) -> AnalysisResult:
    """
    Send source code to Gemini for analysis and return the structured
    Markdown response.

    Args:
        code: The raw source code content to analyze.
        language: Human-readable language name (e.g. "Python").
        filename: Original uploaded filename, used for prompt context.
        model_name: Gemini model identifier to use for generation.

    Returns:
        AnalysisResult: Contains either the successful Markdown content or
        a human-readable error message describing what went wrong.
    """
    try:
        client = get_gemini_client()
    except GeminiNotConfiguredError as exc:
        return AnalysisResult(success=False, error_message=str(exc))

    try:
        prompt = build_analysis_prompt(code=code, language=language, filename=filename)
        config = genai_types.GenerateContentConfig(
            system_instruction=get_system_instruction(),
            **GENERATION_CONFIG_KWARGS,
        )
        response = client.models.generate_content(
            model=model_name,
            contents=prompt,
            config=config,
        )

        # Some Gemini responses can be blocked by safety filters or come
        # back empty; guard against that before returning success.
        response_text = getattr(response, "text", None)
        if not response_text or not response_text.strip():
            return AnalysisResult(
                success=False,
                error_message=(
                    "Gemini returned an empty response. This can happen if "
                    "the content was flagged by safety filters, or if the "
                    "model failed to generate output. Please try again."
                ),
            )

        return AnalysisResult(success=True, content=response_text)

    except Exception as exc:  # noqa: BLE001 - convert any SDK/network error into a UI-safe message
        return AnalysisResult(
            success=False,
            error_message=f"Gemini API request failed: {exc}",
        )
