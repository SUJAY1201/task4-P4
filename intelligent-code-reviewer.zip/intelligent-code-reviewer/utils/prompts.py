"""
prompts.py
==========

Centralized storage for all prompt engineering artifacts used to talk to
Google Gemini.

Keeping prompts separate from application/business logic makes it easy to:
- Version and tune prompts independently of the rest of the codebase.
- Reuse the same prompt templates across multiple entry points (e.g. a CLI
  tool, a test suite, or a different UI) without duplicating strings.
- Review and audit exactly what instructions are being sent to the model.

The system instruction is intentionally strict about the output format so
that `app.py` can reliably parse / render the response as Markdown sections.
"""

# Mapping of file extensions to human-readable language names.
# Used both for syntax highlighting hints and for prompt context.
SUPPORTED_LANGUAGES: dict = {
    ".py": "Python",
    ".js": "JavaScript",
    ".java": "Java",
}

# The exact section headers the model must use. Declared once here so that
# both the prompt template and any downstream parsing logic stay in sync.
SECTION_BUG_REPORT: str = "Bug Report"
SECTION_EXPLANATION: str = "Explanation"
SECTION_IMPROVEMENTS: str = "Improvements"
SECTION_OPTIMIZED_CODE: str = "Optimized Code"


def get_system_instruction() -> str:
    """
    Build the system instruction that forces Gemini into a strict,
    structured Markdown output format.

    The instruction is deliberately explicit and repetitive about formatting
    rules because large language models are more reliable at following
    structure when the constraints are stated clearly and unambiguously.

    Returns:
        str: The full system instruction text.
    """
    return (
        "You are an expert senior software engineer and code reviewer with "
        "deep knowledge of Python, JavaScript, and Java. Your job is to "
        "analyze the source code provided by the user and return your "
        "analysis in a STRICT, CONSISTENT Markdown structure. You must "
        "follow the output format EXACTLY as specified below. Do not add "
        "any extra commentary, greetings, or text outside of the specified "
        "sections. Do not wrap the entire response in a single code block.\n\n"
        "OUTPUT FORMAT (use these exact section headings, in this exact "
        "order, as Markdown H2 headings using '## '):\n\n"
        f"## {SECTION_BUG_REPORT}\n"
        "- List every bug, logical error, edge case failure, or potential "
        "runtime exception you find, as a bullet list.\n"
        "- If there are no bugs, write a single bullet: "
        "'- No significant bugs were found.'\n"
        "- Be specific: reference variable names, line context, or function "
        "names where possible.\n\n"
        f"## {SECTION_EXPLANATION}\n"
        "- Write a clear, plain-language explanation of what the code does, "
        "as flowing prose paragraphs (not bullets).\n"
        "- Describe the overall purpose, the key functions/classes, and the "
        "general control flow.\n\n"
        f"## {SECTION_IMPROVEMENTS}\n"
        "- List concrete, actionable suggestions to improve readability, "
        "performance, maintainability, security, and adherence to best "
        "practices, as a bullet list.\n"
        "- Each bullet should be specific and justified, not generic advice.\n\n"
        f"## {SECTION_OPTIMIZED_CODE}\n"
        "- Provide the FULL refactored/optimized version of the code.\n"
        "- The code MUST be inside a single fenced code block with the "
        "correct language identifier (e.g. ```python, ```javascript, "
        "```java).\n"
        "- The refactored code must be complete and runnable, not a partial "
        "snippet or diff.\n"
        "- Do not include any text after the closing code fence.\n\n"
        "GENERAL RULES:\n"
        "- Always use exactly these four '## ' headings, spelled exactly as "
        "shown, and always in this order.\n"
        "- Never skip a section, even if it is brief.\n"
        "- Never invent code behavior that is not actually present in the "
        "submitted source.\n"
        "- Be technically precise and concise; avoid filler language."
    )


def build_analysis_prompt(code: str, language: str, filename: str) -> str:
    """
    Build the user-turn prompt sent to Gemini for a specific code analysis
    request.

    Args:
        code: The raw source code content to analyze.
        language: Human-readable language name (e.g. "Python").
        filename: Original uploaded filename, used purely for context.

    Returns:
        str: The fully formatted prompt string.
    """
    return (
        f"Analyze the following {language} source code from the file "
        f"'{filename}'.\n\n"
        "Follow the exact output structure defined in your system "
        "instruction (Bug Report, Explanation, Improvements, Optimized "
        "Code).\n\n"
        f"```{language.lower()}\n"
        f"{code}\n"
        "```"
    )


def get_language_from_extension(extension: str) -> str:
    """
    Resolve a human-readable language name from a file extension.

    Args:
        extension: File extension including the leading dot (e.g. ".py").

    Returns:
        str: The human-readable language name, or "Unknown" if unsupported.
    """
    return SUPPORTED_LANGUAGES.get(extension.lower(), "Unknown")
