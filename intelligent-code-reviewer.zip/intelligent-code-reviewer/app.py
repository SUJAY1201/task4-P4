"""
app.py
======

Intelligent Code Reviewer & Explainer
--------------------------------------

A Streamlit application that lets a user upload a `.py`, `.js`, or `.java`
source file, sends it to Google Gemini for analysis, and displays a
structured review consisting of:

- Bug Report
- Explanation
- Improvements
- Optimized / Refactored Code

This file contains ONLY UI/presentation logic. All AI logic lives in
`utils/analyzer.py`, all prompt engineering lives in `utils/prompts.py`,
and all file validation/reading lives in `utils/file_handler.py`.
"""

import re
from typing import Dict, Optional

import streamlit as st
from dotenv import load_dotenv

from utils.analyzer import analyze_code, is_api_key_configured
from utils.file_handler import (
    get_streamlit_language_tag,
    get_supported_extensions,
    validate_and_read_file,
)
from utils.prompts import (
    SECTION_BUG_REPORT,
    SECTION_EXPLANATION,
    SECTION_IMPROVEMENTS,
    SECTION_OPTIMIZED_CODE,
)

# Load environment variables (e.g. GEMINI_API_KEY) from a local .env file,
# if present. In deployed environments, real environment variables take
# precedence automatically.
load_dotenv()

# Ordered list of section headings we expect back from Gemini. Order matters
# for parsing the response into distinct, independently renderable blocks.
EXPECTED_SECTIONS = [
    SECTION_BUG_REPORT,
    SECTION_EXPLANATION,
    SECTION_IMPROVEMENTS,
    SECTION_OPTIMIZED_CODE,
]


def parse_gemini_response(markdown_text: str) -> Dict[str, str]:
    """
    Split a Gemini Markdown response into its named sections.

    The system instruction forces Gemini to use `## <Section Name>` H2
    headings in a fixed order. This function splits on those headings so
    each section can be rendered independently (e.g. so the optimized code
    section can get its own syntax-highlighted code block).

    Args:
        markdown_text: The raw Markdown text returned by Gemini.

    Returns:
        dict[str, str]: Mapping of section name -> section body text.
        Any section not found in the response will be omitted from the
        returned dict, so callers should use `.get()` with a fallback.
    """
    sections: Dict[str, str] = {}

    # Build a regex that captures each "## Heading" and everything after it
    # up until the next "## Heading" or the end of the string.
    heading_pattern = "|".join(re.escape(name) for name in EXPECTED_SECTIONS)
    pattern = re.compile(
        rf"##\s*({heading_pattern})\s*\n(.*?)(?=\n##\s*(?:{heading_pattern})|\Z)",
        re.DOTALL | re.IGNORECASE,
    )

    for match in pattern.finditer(markdown_text):
        heading = match.group(1).strip()
        body = match.group(2).strip()
        # Normalize heading casing to match our known constants.
        for expected in EXPECTED_SECTIONS:
            if heading.lower() == expected.lower():
                sections[expected] = body
                break

    return sections


def extract_code_block(section_text: str) -> Optional[str]:
    """
    Extract the contents of the first fenced code block from a section of
    Markdown text.

    Args:
        section_text: Markdown text that is expected to contain a single
            fenced code block (```language ... ```).

    Returns:
        Optional[str]: The code inside the fences, or None if no fenced
        code block was found.
    """
    match = re.search(r"```[a-zA-Z]*\n(.*?)```", section_text, re.DOTALL)
    if match:
        return match.group(1).strip()
    return None


def render_results(markdown_text: str, language_tag: str) -> None:
    """
    Render a parsed Gemini response into distinct Streamlit UI blocks.

    Falls back to rendering the raw Markdown response if the expected
    section headings cannot be found (e.g. the model deviated slightly
    from the requested format), so the user always sees *something*
    useful rather than a blank page.

    Args:
        markdown_text: The raw Markdown text returned by Gemini.
        language_tag: Streamlit/Pygments language identifier used for
            syntax highlighting the optimized code block.
    """
    sections = parse_gemini_response(markdown_text)

    if not sections:
        st.warning(
            "Could not parse the response into structured sections. "
            "Showing the raw model output below."
        )
        st.markdown(markdown_text)
        return

    # --- Bug Report -------------------------------------------------
    st.subheader("🐛 Bug Report")
    st.markdown(sections.get(SECTION_BUG_REPORT, "_No bug report returned._"))

    st.divider()

    # --- Explanation --------------------------------------------------
    st.subheader("📖 Explanation")
    st.markdown(sections.get(SECTION_EXPLANATION, "_No explanation returned._"))

    st.divider()

    # --- Improvements -------------------------------------------------
    st.subheader("💡 Suggested Improvements")
    st.markdown(sections.get(SECTION_IMPROVEMENTS, "_No improvements returned._"))

    st.divider()

    # --- Optimized Code -------------------------------------------------
    st.subheader("✨ Optimized / Refactored Code")
    optimized_section = sections.get(SECTION_OPTIMIZED_CODE, "")
    code_block = extract_code_block(optimized_section)
    if code_block:
        st.code(code_block, language=language_tag)
    elif optimized_section:
        # No fenced code block detected; show whatever text was returned.
        st.markdown(optimized_section)
    else:
        st.info("No optimized code was returned.")


def render_sidebar() -> None:
    """Render the sidebar with app metadata and API key status."""
    with st.sidebar:
        st.header("ℹ️ About")
        st.markdown(
            "**Intelligent Code Reviewer & Explainer** uses Google Gemini "
            "to analyze source code and return a structured review: bug "
            "report, explanation, improvements, and optimized code."
        )

        st.subheader("Supported file types")
        st.markdown(
            "\n".join(f"- `{ext}`" for ext in get_supported_extensions())
        )

        st.subheader("API Key Status")
        if is_api_key_configured():
            st.success("Gemini API key detected ✅")
        else:
            st.error("Gemini API key NOT found ❌")
            st.caption(
                "Set `GEMINI_API_KEY` in a `.env` file (see `.env.example`) "
                "or as an environment variable, then restart the app."
            )


def main() -> None:
    """Application entry point: configures the page and renders the UI."""
    st.set_page_config(
        page_title="Intelligent Code Reviewer & Explainer",
        page_icon="🧠",
        layout="wide",
    )

    render_sidebar()

    st.title("🧠 Intelligent Code Reviewer & Explainer")
    st.markdown(
        "Upload a source code file and let Gemini generate a bug report, "
        "explanation, improvement suggestions, and an optimized rewrite."
    )

    supported = ", ".join(get_supported_extensions())
    uploaded_file = st.file_uploader(
        f"Upload a source code file ({supported})",
        type=[ext.lstrip(".") for ext in get_supported_extensions()],
    )

    # Nothing uploaded yet: show an informational placeholder and stop.
    if uploaded_file is None:
        st.info("👆 Upload a file above to get started.")
        return

    # --- Validate and read the uploaded file --------------------------
    validation_result = validate_and_read_file(uploaded_file)
    if not validation_result.is_valid:
        st.error(validation_result.error_message)
        return

    code_content = validation_result.content
    language = validation_result.language
    extension = validation_result.extension
    language_tag = get_streamlit_language_tag(extension)

    st.subheader(f"📄 Uploaded File: `{uploaded_file.name}`")
    st.caption(f"Detected language: **{language}**")
    with st.expander("View uploaded source code", expanded=True):
        st.code(code_content, language=language_tag)

    st.divider()

    analyze_clicked = st.button("🔍 Analyze Code", type="primary")

    if not analyze_clicked:
        return

    # --- Guard: missing API key ---------------------------------------
    if not is_api_key_configured():
        st.error(
            "Gemini API key is missing. Please set `GEMINI_API_KEY` in "
            "your `.env` file (see `.env.example`) or as an environment "
            "variable, then restart the app."
        )
        return

    # --- Run analysis with a loading indicator -------------------------
    with st.spinner("Analyzing code with Gemini... this may take a moment."):
        result = analyze_code(
            code=code_content,
            language=language,
            filename=uploaded_file.name,
        )

    if not result.success:
        st.error(f"Analysis failed: {result.error_message}")
        return

    st.success("Analysis complete!")
    render_results(result.content, language_tag)


if __name__ == "__main__":
    main()
